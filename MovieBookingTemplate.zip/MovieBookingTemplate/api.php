<?php

$result = file_get_contents("https://college-movies.herokuapp.com/");

$result = json_decode($result,true);

var_dump($result);
